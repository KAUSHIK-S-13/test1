/* user */

CREATE TABLE user (
  id INT   PRIMARY KEY  AUTO_INCREMENT,
  first_name VARCHAR(30),
  last_name VARCHAR(30),
  user_name VARCHAR(30),
  password VARCHAR(30),
  phone_number VARCHAR(30),
  is_active TINYINT,
  deleted_flag TINYINT,
  created_at TIMESTAMP,
  created_by VARCHAR(30),
  modified_at TIMESTAMP,
  modified_by VARCHAR(30));

