package com.logic.spaza.response;

public class SwaggerConstant  {

		public static final String AUTHENTICATION = "spaza Authentication";
}
